using System;

class Program
{
  public static int entInt(){
    while(true){
      try{
        int x = int.Parse(Console.ReadLine());
        return x;
      } catch (FormatException){
        Console.WriteLine("Invalid input, try again");
      }
    }
  }
    
    public static void Main(string[] args)
    {
        int op;
        Consultorio consultorio = new Consultorio();
        do
        {
            Console.Clear();
            Console.WriteLine("..:::Consultorio Panchos Lopez:::..");
            Console.WriteLine("<1>Ingresar Paciente");
            Console.WriteLine("<2>Mostrar Pacientes");
            Console.WriteLine("<3>Atender Paciente");
            Console.WriteLine("<4>Egresar Paciente");
            Console.WriteLine("<5>Salir");
                Console.WriteLine("Ingrese una opcion:");
                op = Program.entInt();

            if (op == 1)
            {
                consultorio.ingresarPaciente();
                Console.ReadKey();
            }
            else if (op == 2)
            {
                consultorio.mostrar();
                Console.ReadKey();
            }
            else if (op == 3)
            {
                consultorio.atender();
                Console.ReadKey();
            }
            else if (op == 4){
                consultorio.egresar();
                Console.ReadKey();
            }
          
            else if (op == 5)
            {
                Console.WriteLine("Saliendo del sistema...");
                Console.WriteLine("Gracias por preferirnos");
            }
        } while (op != 5);
    }
}

