using System;

class Paciente
{
    int age, edadConocida;
    protected string name, ci;
    bool male;
    int priority;
    private static int loP = 2, hiP = 6;
    private static int AA = 5, In = 4, AR = 3, Par = 2, Norm = 1;

    public Paciente()
    {
        name = null;
        ci = null;
        var ran = new Random();
        age = ran.Next(0, 70);
        edadConocida = -1;
        male = ran.Next(0, 2) == 0;
        string s = "";
        while (s != "1" && s != "0")
        {
            Console.WriteLine("¿Quiere un paciente con un problema de salud con prioridad? (1 = si, 0 = no)");
            s = Console.ReadLine();

            if (s == "1") priority = getPriority(ran);
            else if (s == "0") priority = 1;
            else Console.WriteLine("Ingrese un valor válido.");
        }
    }

    private int getPriority(Random ran)
    {
        int p = -1;
        if (canHaveBaby())
        {
            if (isAdult())
            {
                if (ran.Next(1, 10) == 6)
                {
                    p = ran.Next(loP, hiP);
                }
                else
                {
                    p = ran.Next(loP, hiP);
                    if (p == In) p = AR;
                }
            }
            else
            {
                if (ran.Next(1, 100) == 6)
                {
                    p = ran.Next(loP, hiP);
                }
                else
                {
                    p = ran.Next(loP, hiP);
                    if (p == In) p = AR;
                }
            }
        }
        else
        {
            if (isOld())
            {
                p = ran.Next(loP, hiP);
                if (p == Par) p = AR;
            }
            else if (isAdult())
            {
                if (ran.Next(1, 10) == 6)
                {
                    p = ran.Next(loP, hiP);
                    if (p == Par) p = AR;
                }
                else
                {
                    p = ran.Next(loP, hiP);
                    if (p == Par) p = AR;
                    else if (p == In) p = AR;
                }
            }
            else
            {
                if (ran.Next(1, 100) == 6)
                {
                    p = ran.Next(loP, hiP);
                    if (p == Par) p = AR;
                }
                else
                {
                    p = ran.Next(loP, hiP);
                    if (p == Par) p = AR;
                    else if (p == In) p = AR;
                }
            }
        }
        /*
          if (p < 0)
          {
              Console.WriteLine("\n. .. .\n");
              p = Norm;
          }
        */
        return p;
    }


    public int Age
    {
        get { return age; }
        set { age = value; }
    }

    public bool canHaveBaby()
    {
        return isFemale() && this.age > 12 && this.age < 51;
    }

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public string CI
    {
        get { return ci; }
        set { ci = value; }
    }

    public bool isMale()
    {
        return male;
    }

    public bool isFemale()
    {
        return !male;
    }

    private bool isOld()
    {
        return age > 50;
    }

    public bool isAdult()
    {
        return age > 15;
    }

    public void fillData()
    {
      string s=(isMale())?"masculino":"femenino ";
        Console.WriteLine("\nIngrese el nombre del paciente "+s+": ");
        this.name = Console.ReadLine();
        var isNumeric = int.TryParse(this.ci, out _);
        while (isNumeric == false)
        {
            Console.WriteLine("Ingrese el CI del paciente: ");
            ci = Console.ReadLine();
            isNumeric = int.TryParse(this.ci, out _);
            if (!isNumeric) Console.WriteLine("El CI debe ser un número.");
        }
        this.edadConocida = this.age;
    }

    public string toString()
    {
        string s = "";
        Console.WriteLine("-------------------------------------");
        if (this.name != null) s += "Nombre: " + this.name + ".\n";
        else s += "Nombre: No definido.\n";
        if (this.ci != null) s += "CI: " + this.ci + ".\n";
        else s += "CI: No definido.\n";
        if (this.edadConocida > 0) s += "Edad: " + this.age + ".\n";
        else s += "Edad: No definido.\n";
        if (isAdult()) s += "Persona adulta.\n";
        else s += "Menor de edad.\n";
        if (this.male) s += "Sexo: Masculino.\n";
        else s += "Sexo: Femenino.\n";
        if(this.priority == 1){
        s += "Prioridad: Normal.\n";
        }
        else if(this.priority==2){
        s += "Prioridad: Parto.\n";
        }
        else if(this.priority==3){
        s += "Prioridad: Afecciones Respiratorias.\n";
        }
        else if(this.priority==4){
        s += "Prioridad: Infarto.\n";
        }
        else if(this.priority==5){
        s += "Prioridad: Accidentes Aparatosos.\n";
      }
        return s;
    }

    public int Priority
    {
        get
        {
            return priority;
        }
    }
}