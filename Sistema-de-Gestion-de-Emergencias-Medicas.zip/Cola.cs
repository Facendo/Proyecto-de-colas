using System;

class Cola
{
    private Paciente[] pacientes;
    protected static int max = 25;
    private int numeroDePacientes;

    public Cola()
    {
        pacientes = new Paciente[Cola.max];
        numeroDePacientes = 0;
    }

    public bool push(Paciente paciente)
    {
        bool x = false;
        if (!isFull())
        {  
          pacientes[numeroDePacientes++] = paciente;
            x = true;
        }
        else Console.WriteLine("Cola llena. Se le solicita al paciente buscar servicio en otro sitio.");
        return x;
    }

    public void toOrder()
    {
        if (!isEmpty())
        {
            for (int i = 0; i < Cola.max - 1; i++)
            {
                if (pacientes[i] == null && pacientes[i + 1] != null)
                {
                    pacientes[i] = pacientes[i + 1];
                    pacientes[i + 1] = null;
                }
            }
        }
    }

    public Paciente peek()
    {
        if (!isEmpty()) return pacientes[0];
        Console.WriteLine("Cola vacía");
        return null;
    }

    public Paciente pop()
    {
        Paciente atender;
        if (!isEmpty())
        {
            atender = pacientes[0];
            pacientes[0] = null;
            numeroDePacientes--;
            toOrder();
        }
        else
        {
            Console.WriteLine("Cola vacía");
            atender = null;
        }
        return atender;
    }

    public bool isEmpty()
    {
        return numeroDePacientes == 0;
    }
    public bool isFull()
    {
        return numeroDePacientes == Cola.max;
    }


   
    /*
      static public int Max
      {
          get
          {
              return max;
          }
      }
    */
}