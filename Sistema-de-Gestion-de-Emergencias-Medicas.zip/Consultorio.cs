using System;

class Consultorio
{
    private Doctor[] doctores;
    private Cola[] colas;

    public Consultorio()
    {
        doctores = new Doctor[2];
        doctores[0] = new Doctor(true);
        doctores[1] = new Doctor(false);
        colas = new Cola[10];//Las primeras 5 colas son para niños, las siguientes 5 para adultos.
        for (int i = 0; i < colas.Length; i++) colas[i] = new Cola();
    }

    public void ingresarPaciente()
    {
        Paciente paciente1 = new Paciente();
        if (paciente1.Priority < 3) paciente1.fillData();

        bool repetido = false;
        Cola[] auxColas = new Cola[colas.Length];
        for (int i = 0; i < colas.Length; i++) auxColas[i] = new Cola();
        if (paciente1.CI != null)
        {
            for (int i = 0; i < colas.Length; i++)
            {
                while (!colas[i].isEmpty())
                {
                    Paciente paciente2 = colas[i].pop();
                    if (paciente2.CI == paciente1.CI) repetido = true;
                    auxColas[i].push(paciente2);
                }
                while (!auxColas[i].isEmpty())
                {
                    colas[i].push(auxColas[i].pop());
                }
            }
        }
        if (!repetido)
        {
            int setOff;
            if (paciente1.isAdult()) setOff = 5;
            else setOff = 0;
            colas[(paciente1.Priority - 1) + setOff].push(paciente1);
            Console.WriteLine("Registro exitoso");
        }
        else Console.WriteLine("Registro cancelado: hay otro paciente en cola con la misma cedula.");
    }

    public void mostrar()
    {
        Console.WriteLine("CONSULTAS:");
        doctores[0].mostrarPaciente();
        doctores[1].mostrarPaciente();

        Cola[] auxColas = new Cola[colas.Length];
        for (int i = 0; i < colas.Length; i++) auxColas[i] = new Cola();

        Console.WriteLine("EN COLA: ");

        int j = colas.Length;
        while (j > 0)
        {
            if (colas[j - 1].isEmpty()) j--;
            else
            {
                while(!colas[j - 1].isEmpty()){
                Paciente paciente = colas[j - 1].pop();
                Console.WriteLine(paciente.toString());
                auxColas[j - 1].push(paciente);
                } 
                while(!auxColas[j - 1].isEmpty())colas[j-1].push(auxColas[j - 1].pop());
                j--;
              
            }
        }
    }

    public void atender()
    {
        var ran = new Random();
        int x = ran.Next(0, 2);

        Cola[] colasAux = new Cola[colas.Length / 2];
        for (int i = 0; i < colasAux.Length; i++)
            colasAux[i] = colas[i + x * colas.Length / 2];

        if (x == 0)
        {
            Console.WriteLine("Atendiendo a niños.");
            doctores[0].atender(colasAux);
        }
        else
        {
            Console.WriteLine("Atendiendo a adultos.");
            doctores[1].atender(colasAux);
        }
    }
    public void egresar()
    {
        var ran = new Random();
        int x = ran.Next(0, 2);

        if (x == 0) doctores[0].egresar();
        else doctores[1].egresar();
    }
}