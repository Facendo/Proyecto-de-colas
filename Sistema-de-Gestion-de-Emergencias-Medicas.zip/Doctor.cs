using System;

class Doctor
{
    private bool pediatra;
    private Paciente paciente;

    public Doctor(bool pediatra)
    {
        this.pediatra = pediatra;
        this.paciente = null;
    }

    public bool isPediatra()
    {
        return this.pediatra;
    }

    private void mandarConsulta(Paciente paciente)
    {
        this.paciente = paciente;
    }

    public void atender(Cola[] cola)
    {
        int i;
        for (i = cola.Length - 1; i > -1; i--)
            if (!cola[i].isEmpty()) break;

        if (i > -1)
        {
            mandarConsulta(cola[i].pop());
            Console.WriteLine("Paciente recibido.");
        }
        else if (isPediatra()) Console.WriteLine("No hay ninios en la cola.");
        else Console.WriteLine("No hay adultos en la cola.");

    }

    public void egresar()
    {
        if (this.paciente != null)
        {
            Console.WriteLine("Se egresó a:\n" + paciente.toString());
            this.paciente = null;
        }
        else if (isPediatra()) Console.WriteLine("No hay pacientes ninios para egresar");
        else Console.WriteLine("No hay pacientes adultos para egresar");
    }

    public void mostrarPaciente()
    {
        if (this.paciente != null)
        {
            String s = (isPediatra()) ? "niños" : "adultos";
            Console.WriteLine("Paciente en consulta para " + s + ":\n " + paciente.toString());
        }
        else Console.WriteLine("No hay paciente en consulta.");
    }
    public string toString()
    {
        String x = null;
        if (this.paciente != null)
        {
            String s = (isPediatra()) ? "niños" : "adultos";
            x = "Paciente en consulta para " + s + ":\n " + paciente.toString();
        }
        return x;
    }
}